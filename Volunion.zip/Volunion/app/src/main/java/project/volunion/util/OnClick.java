package project.volunion.util;

public interface OnClick<T> {
    void onClicked(T clickedObject);
}
