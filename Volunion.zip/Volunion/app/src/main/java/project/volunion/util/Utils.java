package project.volunion.util;

public class Utils {

    public static String KURUM_GONULLULERI = "RegisteredVolunteers";
    public static String ADMIN_MAIL = "project.volunion@gmail.com";
    public static String ADMIN_PASSWOD= "14081997gul";

    //SharedPreferences Keys
    public static String GONULLU_EMAIL = "Gonullu_Email";
    public static String KURUM_BILGI = "Kurum_Bilgi";
    public static String KURUM_ID = "Kurum_Id";

}
