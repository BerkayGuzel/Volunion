package project.volunion.util;

public interface OnClickDeleteUser<T> {
    void onDeleted(T clickedObject);
}
