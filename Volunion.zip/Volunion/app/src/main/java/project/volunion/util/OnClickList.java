package project.volunion.util;

public interface OnClickList<T> {
    void onClicked(T clickedObject);
}
