package project.volunion.util;

public interface OnClickSendEmailUser<T> {
    void onSendMail(T clickedObject);
}
